# lista zakupow
print("zakupki")

zakupy = ["Chleb", "Mleko", "Jajka"]
zakupy.append("Czekolada") # Dodajemy coś do listy

print(f"Masz do kupienia {len(zakupy)} rzeczy:")

# Pętla przechodzi przez każdy element listy
for produkt in zakupy:
    print(f"- {produkt}")

# Sprawdzanie czy element jest na liście
if "Czekolada" in zakupy:
    print("nie zapomnij o czekoladce")

# zakupy[0]: To pierwsza szuflada. W Pythonie zawsze zaczynamy liczyć od 0.

# append(): Dokłada nową rzecz na sam koniec regału.

# for produkt in zakupy:: Program bierze pierwszy element z listy, nazywa go tymczasowo zmienną produkt, wykonuje kod pod spodem (wypisuje go), a potem wraca po kolejny element. Robi to tak długo, aż lista się skończy.

# in: To bardzo ludzkie słowo – sprawdza po prostu, czy dany tekst znajduje się gdzieś wewnątrz listy.

# len(zakupy) wypisuje ile ilość rzeczy w liście "zakupy"