# cena bileciku
print("cena bileciku")

wiek = int(input("Ile masz lat? "))
dzien = input("Jaki dziś dzień tygodnia? ").lower()

if wiek < 7 or dzien == "poniedziałek":
    print("Wchodzisz za darmo!")
elif wiek >= 7 and wiek <= 18:
    print("Bilet ulgowy: 15 zł")
else:
    print("Bilet normalny: 25 zł")

# .lower():  można wpisać "Poniedziałek", "PONIEDZIAŁEK" albo "poniedziałek". Ta funkcja zamienia wszystko na małe litery, żeby "if" zawsze odczytał to tak samo.


# Operatory logiczne:

# or (lub): Wystarczy, że jeden z warunków jest prawdziwy (masz mniej niż 7 lat LUB jest poniedziałek), a wchodzisz do kina za darmo.

# and (i): Oba warunki muszą być prawdziwe jednocześnie (musisz mieć więcej niż 7 lat I mniej niż 18).

# Kolejność: Python sprawdza warunki po kolei. Jeśli (if) jest prawdziwy, resztę warunków (elif, else) całkowicie ignoruje. Jeśli (if) jest fałszywy Python przechodzi do następnego warunku, czyli (elif).
# Jeśli (elif) jest fałszywy Python przechodzi do następnego warunku (elif) lub (else) zależnie od ilości warunków. (else) Zawsze jest ostatnim warunkiem.