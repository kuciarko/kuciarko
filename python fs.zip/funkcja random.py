import random

# Definiujemy funkcję, która "rzuca" kością tyle razy, ile chcemy
def rzut_koscia(ile_razy):
    print(f"Rzucam kością {ile_razy} razy:")
    for i in range(ile_razy):
        wynik = random.randint(1, 6)
        print(f"Rzut {i+1}: Wypadło {wynik}")

# Wywołujemy naszą funkcję
ile = int(input("Ile razy chcesz rzucić kością? "))
rzut_koscia(ile)

# import random: Biblioteka random nie jest ładowana domyślnie, żeby nie obciążać pamięci. Musisz ją "zawołać" na początku.

# def rzut_koscia(ile_razy)::

# def to skrót od define (zdefiniuj).

# ile_razy to tzw. argument. To puste miejsce, do którego "wpada" liczba, którą podasz później (np. z input).

# Zasięg: Wszystko, co jest pod def (z wcięciem), nie wykona się samo z siebie. To tylko instrukcja. Program ruszy dopiero w ostatniej linii, gdy "zawołasz" funkcję po nazwie: rzut_koscia(ile).