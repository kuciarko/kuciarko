# pole prostokąta
print("pole prostokąta")

dlugosc = input("Podaj długość boku: ")
szerokosc = input("Podaj szerokość boku: ")

# Zmieniamy tekst (str) na liczby (float), żeby móc mnożyć
pole = float(dlugosc) * float(szerokosc)

print(f"Pole Twojego prostokąta wynosi: {pole}")
print("Typ zmiennej 'pole' to:", type(pole))

# input(): To funkcja, która zawsze "widzi" to, co wpiszesz, jako tekst (string). Nawet jeśli wpiszesz 5, dla komputera to jest znak graficzny, a nie liczba.

# float(): To "zaklęcie", które zmienia tekst na liczbę zmiennoprzecinkową. Bez tego próba pomnożenia dlugosc * szerokosc skończyłaby się błędem, bo nie da się mnożyć tekstu przez tekst.

# f"...": To tzw. f-string. Pozwala wstawić zmienną (np. {pole}) bezpośrednio do środka zdania bez przerywania cudzysłowu.